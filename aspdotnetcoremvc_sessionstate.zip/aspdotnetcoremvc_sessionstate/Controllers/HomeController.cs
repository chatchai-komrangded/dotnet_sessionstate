﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using aspdotnetcoremvc_sessionstate.Models;
using Microsoft.AspNetCore.Http;
using Amazon.Util;

namespace aspdotnetcoremvc_sessionstate.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //Load data from distributed data store asynchronously
            HttpContext.Session.LoadAsync();
            
            //Get value from session
            var views = (int)(HttpContext.Session.GetInt32("Viewcount") ?? 0) + 1;
            HttpContext.Session.SetInt32("Viewcount", views);
            HttpContext.Session.CommitAsync();

            ViewData["Message"] = HttpContext.Session.GetInt32("Viewcount");

            var loginName = HttpContext.Session.GetString("username");

            if (loginName == null) {
                HttpContext.Session.SetString("username", "ck");
                HttpContext.Session.CommitAsync();
            }
            ViewData["Username"] = HttpContext.Session.GetString("username");
            ViewData["Hostname"] = EC2InstanceMetadata.Hostname;



            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
