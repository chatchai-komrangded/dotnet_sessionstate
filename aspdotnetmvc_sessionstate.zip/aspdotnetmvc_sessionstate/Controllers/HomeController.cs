﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using Amazon.Util;

namespace aspdotnetmvc_sessionstate.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var views = (int)(Session["ViewCount"] ?? 0) + 1;
            Session["ViewCount"] = views;

            ViewData["Message"] = views;

            ViewData["Hostname"] = EC2InstanceMetadata.Hostname;

            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}